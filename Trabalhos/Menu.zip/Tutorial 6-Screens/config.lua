application =
{
	content =
	{
		graphicsCompatibility = 1,
		width = 320,
		height = 480,
		scale = "zoomStretch",
		
		imageSuffix =
		{
			["@15x"] = 1.5,
			["@2x"] = 2.1,
		},
	}
}